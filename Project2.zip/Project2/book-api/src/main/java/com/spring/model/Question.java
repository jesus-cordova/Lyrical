package com.spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name = "Question")
@Table(name = "question")
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator= "QuestionProject")
	@SequenceGenerator(name="QuestionProject", sequenceName="QuestionProject_S", allocationSize=1)
	@Column(name = "question_id") 
	private int id;
	@Column(name = "question")
	private String question;
	@Column(name = "option1")
	private String option1;
	@Column(name = "option2")
	private String option2;
	@Column(name = "option3")
	private String option3;
	@Column(name = "answer")
	private double answer;
	@Column(name = "useranswer")
	private double useranswer;
	@Column(name = "unique_id")
	private String uniqueId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getOption1() {
		return option1;
	}
	public void setOption1(String option1) {
		this.option1 = option1;
	}
	public String getOption2() {
		return option2;
	}
	public void setOption2(String option2) {
		this.option2 = option2;
	}
	public String getOption3() {
		return option3;
	}
	public void setOption3(String option3) {
		this.option3 = option3;
	}
	public double getAnswer() {
		return answer;
	}
	public void setAnswer(double answer) {
		this.answer = answer;
	}
	public double getUseranswer() {
		return useranswer;
	}
	public void setUseranswer(double useranswer) {
		this.useranswer = useranswer;
	}
	
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	@Override
	public String toString() {
		return "Quiz [id=" + id + ", question=" + question + ", option1=" + option1 + ", option2=" + option2
				+ ", option3=" + option3 + ", answer=" + answer + ", useranswer=" + useranswer + "]";
	}
	
	//@OneToMany(mappedBy="quiz")
	//@JoinColumn(name = "quiz_id")
	//@Column(name = "quiz_id")
	//private List<Quiz> quiz= new ArrayList<Quiz>();
}
