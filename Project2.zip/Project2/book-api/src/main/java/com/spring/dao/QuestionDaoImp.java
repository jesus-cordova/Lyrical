package com.spring.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.model.Question;

@Repository
public class QuestionDaoImp implements QuestionDao {

   @Autowired
   private SessionFactory sessionFactory;

   @Override
   public int save(Question question) {
      sessionFactory.getCurrentSession().save(question);
      return question.getId();
   }

   @Override
   public Question get(String uniqueId) {
      return sessionFactory.getCurrentSession().get(Question.class,uniqueId);
   }

   @Override
   public List<Question> list() {
      List<Question> list = sessionFactory.getCurrentSession().createQuery("from Question").list();
      return list;
   }

   @Override
   public void update(int id, Question question) {
      Session session = sessionFactory.getCurrentSession();
      Question quiz2 = session.byId(Question.class).load(id);
      quiz2.setOption1(question.getOption1());
      quiz2.setOption2(question.getOption2());
      quiz2.setOption3(question.getOption3());
      quiz2.setQuestion(question.getQuestion());
      quiz2.setUseranswer(question.getUseranswer());
      session.flush();
   }

   @Override
   public void delete(int id) {
      Question book = sessionFactory.getCurrentSession().byId(Question.class).load(id);
      sessionFactory.getCurrentSession().delete(book);
   }

}
