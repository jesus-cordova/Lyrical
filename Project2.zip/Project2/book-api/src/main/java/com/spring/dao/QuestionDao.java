package com.spring.dao;

import java.util.List;

import com.spring.model.Question;

public interface QuestionDao {

   int save(Question question);

   Question get(String id);

   List<Question> list();

   void update(int id, Question question);

   void delete(int id);

}
