package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dao.QuestionDao;
import com.spring.model.Question;


@Service
@Transactional(readOnly = true)
public class QuestionServiceImp implements QuestionService {

   @Autowired
   private QuestionDao questionDao;

   @Transactional
   @Override
   public int save(Question question) {
      return questionDao.save(question);
   }

   @Override
   public Question get(String id) {
      return questionDao.get(id);
   }

   @Override
   public List<Question> list() {
      return questionDao.list();
   }

   @Transactional
   @Override
   public void update(int id, Question question) {
      questionDao.update(id, question);
   }

   @Transactional
   @Override
   public void delete(int id) {
      questionDao.delete(id);
   }

}
