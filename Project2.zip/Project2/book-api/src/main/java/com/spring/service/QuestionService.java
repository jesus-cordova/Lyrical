package com.spring.service;

import java.util.List;

import com.spring.model.Question;

public interface QuestionService {

   int save(Question question);
   Question get(String uniqueId);
   List<Question> list();
   void update(int id, Question question);
   void delete(int id);
}
