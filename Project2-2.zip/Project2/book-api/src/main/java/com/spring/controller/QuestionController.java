package com.spring.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Question;
import com.spring.service.QuestionService;
@CrossOrigin(origins = "*")

@RestController
//@RequestMapping("/api")
@Controller 
public class QuestionController {

   @Autowired
   private QuestionService questionService;
	//@CrossOrigin(origins = "http://localhost:8081")

   @PostMapping("/api/quiz")
   public ResponseEntity<?> save(@RequestBody Question question) {
      long id = questionService.save(question);
      return ResponseEntity.ok().body("New Question has been saved with ID:" + id);
   }
   

   @GetMapping("/api/quiz/{uniqueid}")
   public ResponseEntity<Question> get(@PathVariable("uniqueid") String uniqueid) {
      Question question = questionService.get(uniqueid);
	 
      return ResponseEntity.ok().body(question);
   }

  
   ///book old dir
   @GetMapping("/api/quiz")
   public ResponseEntity<List<Question>> list() {
      List<Question> question = questionService.list();
      return ResponseEntity.ok().body(question);
   }

   
   @PutMapping("/api/quiz/{id}")
   public ResponseEntity<?> update(@PathVariable("id") int id, @RequestBody Question question) {
      questionService.update(id, question);
      return ResponseEntity.ok().body("Question has been updated successfully.");
   }

   /*
   @DeleteMapping("/book/{id}")
   public ResponseEntity<?> delete(@PathVariable("id") int id) {
      bookService.delete(id);
      return ResponseEntity.ok().body("Book has been deleted successfully.");
   }
   */
}